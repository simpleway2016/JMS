﻿
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;


namespace $safeprojectname$.Controllers
{
    public class BaseController : MicroServiceControllerBase
{
    SystemDBContext _CurrentDBContext;
    /// <summary>
    /// 当前线程的DBContext对象
    /// </summary>
    public SystemDBContext CurrentDBContext
    {
        get
        {
            return _CurrentDBContext ??= new SystemDBContext();
        }
    }

    public override bool OnInvokeError(string actionName, object[] parameters, Exception error)
    {
        base.OnInvokeError(actionName, parameters, error);

        if (_CurrentDBContext != null)
        {
            _CurrentDBContext.Dispose();
            _CurrentDBContext = null;
        }

        if (error is ServiceException)
            return true; // return true表示不用生成日志

        return false;
    }

    public override void OnAfterAction(string actionName, object[] parameters)
    {
        base.OnAfterAction(actionName, parameters);

        if (_CurrentDBContext != null)
        {
            if (_CurrentDBContext.CurrentTransaction != null)
            {
                //如果数据库开启了事务，把事务放到委托当中
                var db = _CurrentDBContext;
                this.TransactionControl = new JMS.TransactionDelegate(this);
                this.TransactionControl.CommitAction = () =>
                {
                    using (db)
                    {
                        db.CommitTransaction();
                    }
                };
                this.TransactionControl.RollbackAction = () =>
                {
                    using (db)
                    {
                        db.RollbackTransaction();
                    }
                };

                _CurrentDBContext = null;
            }
            else
            {
                _CurrentDBContext.Dispose();
                _CurrentDBContext = null;
            }
        }
    }

    public override void OnUnLoad()
    {
        base.OnUnLoad();

        if (_CurrentDBContext != null)
        {
            _CurrentDBContext.Dispose();
            _CurrentDBContext = null;
        }
    }
}
}
