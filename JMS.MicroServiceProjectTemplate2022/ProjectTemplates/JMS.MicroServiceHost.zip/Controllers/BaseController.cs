﻿
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;


namespace $safeprojectname$.Controllers
{
    public class BaseController : MicroServiceControllerBase
{
    SystemDBContext _CurrentDBContext;
    /// <summary>
    /// 当前线程的DBContext对象
    /// </summary>
    public SystemDBContext CurrentDBContext
    {
        get
        {
            return _CurrentDBContext ??= this.ServiceProvider.GetService<SystemDBContext>();
        }
    }

    public override bool OnInvokeError(string actionName, object[] parameters, Exception error)
    {
        base.OnInvokeError(actionName, parameters, error);

        if (error is ServiceException)
            return true; // return true表示不用生成日志

        return false;
    }

    public override void OnAfterAction(string actionName, object[] parameters)
    {
        base.OnAfterAction(actionName, parameters);

        if (_CurrentDBContext != null && _CurrentDBContext.CurrentTransaction != null)
        {
                this.TransactionControl = new JMS.TransactionDelegate(this , _CurrentDBContext);
        }
    }

}
}
