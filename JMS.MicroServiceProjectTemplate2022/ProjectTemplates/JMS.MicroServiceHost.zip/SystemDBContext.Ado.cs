﻿//using Microsoft.Data.SqlClient;
//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Text;
//using System.Threading;

//namespace $safeprojectname$
//{
//    /// <summary>
//    /// 这只是一个假的dbcontext,只是用来示范如何控制事务
//    /// 你可以按实际情况，编写一个类似的数据库操作对象
//    /// </summary>
//    public class SystemDBContext : IDisposable
//    {
//        static ThreadLocal<SystemDBContext> _CurrentDBContextThread = new ThreadLocal<SystemDBContext>();
//        /// <summary>
//        /// 获取当前线程对应的dbcontext
//        /// </summary>
//        public static SystemDBContext CurrentDBContext
//        {
//            get
//            {
//                if (_CurrentDBContextThread.Value == null)
//                    _CurrentDBContextThread.Value = new SystemDBContext();

//                return _CurrentDBContextThread.Value;
//            }
//            set
//            {
//                if (_CurrentDBContextThread.Value != null)
//                {
//                    _CurrentDBContextThread.Value.Dispose();
//                    _CurrentDBContextThread.Value = null;
//                }
//            }
//        }

//        /// <summary>
//        /// 当前事务对象
//        /// </summary>
//        public IDbTransaction CurrentTransaction
//        {
//            get;
//            private set;
//        }

//        public IDbConnection Connection => _connection;

//        SqlConnection _connection;
//        public SystemDBContext()
//        {
//            var connectionStr = "server=127.0.0.1;uid=sa;pwd=1;database=test";//你的连接字符串
//            _connection = new SqlConnection(connectionStr);
//            _connection.Open();
//        }

//        public void BeginTransaction()
//        {
//            this.CurrentTransaction = _connection.BeginTransaction();
//        }
//        public void CommitTransaction()
//        {
//            this.CurrentTransaction?.Commit();
//            this.CurrentTransaction = null;
//        }

//        public void RollbackTransaction()
//        {
//            this.CurrentTransaction?.Rollback();
//            this.CurrentTransaction = null;
//        }

//        public void Dispose()
//        {
//            this.CurrentTransaction?.Dispose();
//            this.CurrentTransaction = null;
//            _connection.Dispose();
//        }

//    }
//}
