﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace $safeprojectname$
{
    /// <summary>
    /// 这只是一个假的dbcontext,只是用来示范如何控制事务
    /// 你可以按实际情况，编写一个类似的数据库操作对象
    /// </summary>
    public class SystemDBContext : IDisposable
    {       

        /// <summary>
        /// 当前事务对象
        /// </summary>
        public object CurrentTransaction { get; set; }

        public void BeginTransaction()
        {
            this.CurrentTransaction = new object();
        }
        public void CommitTransaction() {
            this.CurrentTransaction = null;
        }
        public void RollbackTransaction() {
            this.CurrentTransaction = null;
        }

        public void Dispose()
        {
            this.CurrentTransaction = null;
        }
    }
}
