﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Storage;
//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Threading;

//namespace $safeprojectname$
//{
//    /// <summary>
//    /// 请把父类改为你相应db context类
//    /// 请引用相关的Microsoft.EntityFrameworkCore包
//    /// </summary>
//    public class SystemDBContext : DbContext
//    {
//        static ThreadLocal<SystemDBContext> _CurrentDBContextThread = new ThreadLocal<SystemDBContext>();
//        /// <summary>
//        /// 获取当前线程对应的dbcontext
//        /// </summary>
//        public static SystemDBContext CurrentDBContext
//        {
//            get
//            {
//                if (_CurrentDBContextThread.Value == null)
//                    _CurrentDBContextThread.Value = new SystemDBContext();

//                return _CurrentDBContextThread.Value;
//            }
//            set
//            {
//                if (_CurrentDBContextThread.Value != null)
//                {
//                    _CurrentDBContextThread.Value.Dispose();
//                    _CurrentDBContextThread.Value = null;
//                }
//            }
//        }

//        /// <summary>
//        /// 当前事务对象
//        /// </summary>
//        public IDbContextTransaction CurrentTransaction => this.Database.CurrentTransaction;

//        public void BeginTransaction()
//        {
//            this.Database.BeginTransaction();
//        }
//        public void CommitTransaction()
//        {
//            this.Database.CommitTransaction();
//        }
//        public void RollbackTransaction()
//        {
//            this.Database.RollbackTransaction();
//        }
//    }
//}
